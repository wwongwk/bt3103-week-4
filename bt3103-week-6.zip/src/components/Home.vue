<template>
  <div>
    <page-content> </page-content>
  </div>
</template>

<script>
import PageContent from "./PageContent.vue";
export default {
  components: { PageContent },
};
</script>

<style scoped>
</style>